#include"housedetails.h"

void HouseDetails::setHouseId(string id)
{
	this->houseId=id;
}

string HouseDetails::getHouseId()
{
	return this->houseId;
}

void HouseDetails::setHouseType(string type)
{
	this->houseType=type;
}

string HouseDetails::getHouseType()
{
	return this->houseType;
}
